from django.shortcuts import render
from django.http import JsonResponse, HttpResponse
from django.shortcuts import redirect, render
from django.forms.models import model_to_dict
import os
import pandas as pd
import json
from .models import *
import datetime
from django.db.models import Count

class Article():
    def __init__(self) -> None:
        pass    
    def write(request):
        if request.method == 'POST':
            title = request.POST.get('title')
            content = request.POST.get('content')
            user = Users.objects.get(email=request.session['email'])
            time = datetime.datetime.now().strftime('%Y-%m-%d')
            article = Article_list(title = title, content = content, user = user, date = time)
            article.save()
            
            return redirect('/read_article/?article_id=%s'%article.id)
        else:
            return render(request, 'study/write_article.html')
    def update(request):
        if request.method == 'POST':
            return HttpResponse(1)
        else:
            return HttpResponse(1)
    def remove(request):
        if request.method == 'POST':
            return HttpResponse(1)
        else:
            return HttpResponse(1)
    def read(request):
        mode= request.GET.get('mode')
        article_id =request.GET.get('article_id')
        if mode == 'just_show':
            email = request.session['email']
            user = Users.objects.get(email=email)
            article_list = user.article_list_set.all()
            article_list_list = []
            # print(article_list.values('date').annotate(count = Count('date')))
            article_dict = {}
            for date in article_list.values('date').annotate(count = Count('date')):
                date = date['date']
                date_articles = article_list.filter(date= date)
                date_list = []
                for article in date_articles:
                    date_list.append(model_to_dict(article))
                article_dict[date]=date_list
            print(article_dict)
            return render(request, 'study/just_show_article_list.html',{'article_dict':article_dict})
        if mode == 'by_date':
            return HttpResponse(1)
        if mode == 'by_tag':
            return HttpResponse(1)
        if mode == 'by_previous':
            return HttpResponse(1)
        if article_id:
            target_article = Article_list.objects.get(id = article_id)
            return render(request, 'study/read_article.html', {'target_article':target_article})
class Tag():
    def __init__(self) -> None:
        pass
    def read_base_tags(request):
        return HttpResponse('h1')
    def read_sub_tags(request):
        return HttpResponse('h1')
    def read_all_tags(request):
        try:
            if request.session['email']:
                level_zero_tags = Tag_list.objects.filter(tag_level__contains=0)
                level_one_tags = Tag_list.objects.filter(tag_level__contains=1)
                level_two_tags = Tag_list.objects.filter(tag_level__contains=2)
                context ={'level_zero_tags' : level_zero_tags,'level_one_tags' : level_one_tags,'level_two_tags' : level_two_tags } 
                return render(request, 'study/read_all_tag.html' ,context)
        except:
            return redirect('/')
    def make_new_tag(request):
        if request.method == 'POST':
            data = json.loads(request.body)
            print(data)
            if data['tag_name']=='':
                return JsonResponse({'status':'저장할 이름을 입력해야합니다.'})
            else:
                Tag_list(tag_name=data['tag_name'], tag_level=data['tag_depth']).save()
                return JsonResponse({'status':'저장완료'})
        else:
            HttpResponse('get접근')
def make_site_bookmark(request):
    try:
        if request.session['email']:
            email = request.session['email']
            user = Users.objects.get(email = email)
            all_site_info = Site_Info.objects.filter(user= user)
            list_ = []
            for i in all_site_info:
                list_.append(model_to_dict(i))
            return render(request, 'study/make_site_bookmark.html', {'site_list_half01' :list_[:len(list_)//2], 'site_list_half02':list_[len(list_)//2:]})
    except:
        return render(request, 'study/nosession.html')
def save_user_favorite_site(request):
    if request.method =='POST':
        user_email = request.session['email']
        user = Users.objects.get(email= user_email)
        data = json.loads(request.body)
        mode = data['mode']
        site_list = data['site_list']
        list_ = []
        if mode=='get_user_check':
            sites = Site_Info.objects.filter(user=user)
            print(1)
            # 유저의 사이트를 일단 다꺼준다
            for each_site in sites:
                each_site.onoff = 0
                each_site.save()
                # 요청받은 사이트리스트를 다시켜준다
            for i in site_list:
                print(i)
                site = Site_Info.objects.filter(virtual_site_name = i, user= user)
                for x in site:
                    x.onoff = 1
                    x.save()
            # site_exclued = Site_Info.objects.exclude(site_name__in = site_list)
            return HttpResponse(site_list)
        if mode == 'load_checked':
            user_favorite_site_list = Site_Info.objects.filter(user=user, onoff=1)
            for i in user_favorite_site_list:
                list_.append(model_to_dict(i))
            return JsonResponse(list_, safe=False)
def save_new_site_info(request):
    if request.method == 'POST':
        user = Users.objects.get(email = request.session['email'])
        file = request.FILES['new_favorite_site_img']
        file_name = file.name
        file_binary = file.read()
        site_url = request.POST.get('site_url')
        if site_url[:4] !='http':
            site_url = 'http://'+site_url
        site_name = request.POST.get('site_name')
        user_sites = Site_Info.objects.filter(user= user)
        site_list = []
        for h in user_sites:
            site_list.append(h.site_name)
        if site_name in site_list:
            virtual_site_name = site_name+str(time())
        else:
            virtual_site_name = site_name
        print(file, site_url, site_name)
        file_name = file_name[:file_name.rfind('.')]+str(time()).replace('.','')+file_name[file_name.rfind('.')-1:]
        with open('study/static/img/사이트아이콘/%s'%file_name, 'wb') as f:
            f.write(file_binary)
        file_img_link = 'img/사이트아이콘/%s'%file_name
        new_site = Site_Info(site_name = site_name, site_url_link= site_url, site_img_link=file_img_link, onoff=1, user= user, virtual_site_name = virtual_site_name)
        new_site.save()
        # path = default_storage.save('study/static/img/save_user_file/favorite_site/image/%s'%file_name,file)
        return HttpResponse(1)
# def to_db(request):
#     # 자주가는 사이트 데이터베이스에 반영시키는
#     if request.GET.get('mode'):
#         mode = request.GET.get('mode')
#         if mode == 'save_site':
#             dic = {}
#             with open('study/static/홈피링크.txt', 'r', encoding='utf-8') as file:
#                 a = file.read()
#                 print(type(a))
#                 a = a.split('\n')
                
#                 for i in a[:-1]:
#                     b = i.split('&')
#                     dic[b[0]]=b[1]
#                     img_link = 'img/사이트아이콘/%s.png'
#                     img_link = img_link%b[0]
#                     Site_Info(site_name=b[0], site_url_link=b[1] , site_img_link=img_link).save()                    
#             return HttpResponse(dic.items())
#     # 기본태그 넣어주는
#     with open('json/tag.json', 'r', encoding='utf-8') as f:
#         r = f.read()
#         r  =json.loads(r)
#         print(type(r), len(r['level']))
#         for i in range(len(r['level'])):
#             Tag_list(tag_name = r['name'][str(i)], tag_level=r['level'][str(i)]).save()
#     return HttpResponse('ok')
# Create your views here.
def signin(request):
    if request.method =='POST':
    #받은 회원가입 정보를 처리하는 과정
        email = request.POST.get('email')
        email_domain =request.POST.get('email_domain')
        db_email = '@'.join([email, email_domain])
        password = request.POST.get('user_pw')
        password_re = request.POST.get('check_pw')
        name=request.POST.get('name')
        nickname = request.POST.get('nickname')
        birthday_year=request.POST.get('birthday_year')
        birthday_month=request.POST.get('birthday_month')
        birthday_date=request.POST.get('birthday_date')
        birthday = '/'.join([birthday_year, birthday_month, birthday_date])
        gender=request.POST.get('gender')
        phone = request.POST.get('phone')
        signup_date = datetime.datetime.now().strftime('%Y%m%d') 
    #유효성검사
        #이메일에 대한 유효성검사
        domain_pattern = re.compile('[a-zA-Zㄱ-힣]+\.{1}[a-zA-Z]+')
        email_pattern = re.compile('[a-zA-Z0-9]+')
        if Users.objects.filter(email__contains = db_email):
            return render(request,'study/signin.html', {'status_code':'중복되는 이메일이 존재합니다'})
        elif email=='undefined' or email=='none':
            return render(request,'study/signin.html', {'status_code':'이메일 필수'})
        elif email_pattern.fullmatch(str(email))==None:
            return render(request,'study/signin.html', {'status_code':'이메일 형식이 올바르지 않습니다.'}) 
        elif domain_pattern.fullmatch(str(email_domain))==None:
            return render(request,'study/signin.html', {'status_code':'도메인 형식이 올바르지 않습니다'})  
        #이메일상에는 문제가없을때
        elif password!=None and name !=None and nickname !=None and birthday_year != None and birthday_month != None and birthday_date != None and gender != None and phone !=None:
            if password != password_re:
                return render(request,'study/signin.html', {'status_code':'비밀번호 확인을 비밀번호와 동일하게 작성해주세요'})  
            else:
                # 먼저 유저 생성
                saved_user = Users(name=name,birthday=birthday,gender=gender,password=password,nickname=nickname,email=db_email, phone=phone, signup_date = signup_date)
                saved_user.save()
            # 그유저의 아이디에 연결된 태그리스트 테이블에, 기본제공이 되는 태그리스트 부여
                with open('json/tag.json', 'r', encoding='utf-8') as f:
                    r = f.read()
                    r  =json.loads(r)
                    for i in range(len(r['level'])):
                        Tag_list(tag_name = r['name'][str(i)], tag_level=r['level'][str(i)],user = saved_user).save()
            # 기본 제공되는 자주가는 사이트 목록 부여
                dic = {}
                with open('study/static/홈피링크.txt', 'r', encoding='utf-8') as file:
                    a = file.read()
                    print(type(a))
                    a = a.split('\n')
                    
                    for i in a[:-1]:
                        b = i.split('&')
                        dic[b[0]]=b[1]
                        img_link = 'img/사이트아이콘/%s.png'
                        img_link = img_link%b[0]
                        Site_Info(site_name=b[0], site_url_link=b[1] , site_img_link=img_link, user = saved_user, onoff = 0, virtual_site_name = b[0]).save()   
                return redirect('/')
        else:
            return render(request,'study/signin.html', {'status_code':'모든 정보를 입력해주세요'})  
    try:
    #세션을 가진채로 회원가입 창에 접근할때, check함수를 거쳐 세션을 확인받고 home으로 이동할 수 있게.
        if request.session['email']:
            return redirect('/')
    except:
        return render(request, 'study/signin.html', {'status_code':'최초접근'})
        
def check(request):
    try:
        if request.session['email']:
            user = Users.objects.get(email__contains = request.session['email'])
            return render(request, 'study/home.html')      
    except:
        return render(request, 'study/nosession.html')
def logout(request):
    request.session.flush()
    return redirect('/')
def remove_session(request):
    request.session.flush()
    return HttpResponse('/')



import re
####비동기 처리용
def login(request):
    if request.method == 'POST':
        dict = json.loads(request.body)
        email = dict['email']
        user_pw = dict['user_pw']
        if Users.objects.filter(email=email, password=user_pw):
            request.session['email']=email
            request.session['nickname']=Users.objects.filter(email=email, password=user_pw)[0].nickname
            request.session['user_pw'] =user_pw
            request.session['profile_image'] =Users.objects.filter(email=email, password=user_pw)[0].profile_image
            status = '로그인정보일치'
            context={'status':status}
            return JsonResponse(context)
        else:
            status = '로그인오류'
            context={'status':status}
            return JsonResponse(context)
            
    else:
        return HttpResponse(1)
def verify_new_email(request):
    request_email = request.GET.get('email')
    request_email_domain = request.GET.get('email_domain')
    pattern = re.compile('[a-zA-Zㄱ-힣]+\.{1}[a-zA-Z]+')
    pattern2 = re.compile('[a-zA-Z0-9]+')
    if request_email=='undefined' or request_email=='none':
        return JsonResponse({'status':'이메일입력필수'})
    if pattern2.fullmatch(str(request_email))==None:
        return JsonResponse({'status':'이메일 형식이 올바르지 않습니다.'})       
    if pattern.fullmatch(str(request_email_domain))==None:
        return JsonResponse({'status':'도메인 형식이 올바르지 않습니다'})       
    else:
        email = '@'.join([request_email, request_email_domain])
        print(email)
        if Users.objects.filter(email__contains=email):
            return JsonResponse({'status':'이미 존재하는 사용자'})
        else:
            return JsonResponse({'status':'사용가능'})
def mypage(request):
    try:
        if request.session['email']:
            email = request.session['email']
            user = Users.objects.get(email__contains = email)
    except:
        user={1:1}
        pass
    return render(request, 'study/mypage.html', {'user':user})
from django.core.files.storage import default_storage
from time import time
def file_upload(request):
    if request.method == 'POST':
        email = request.session['email']
        user = Users.objects.get(email__contains = email)
        before_img_link = 'study/static/'+user.profile_image
        if user.profile_image != 'img/save_user_file/profile/image/default_img.jpg':
            os.remove(before_img_link)
            os.path.isdir(before_img_link)
        data = request.POST
        file = request.FILES['profile_img_file']
        print(file)
        file_name = file.name
        file_name = file_name[:file_name.rfind('.')]+str(time()).replace('.','')+file_name[file_name.rfind('.')-1:]
        path = default_storage.save('study/static/img/save_user_file/profile/image/%s'%file_name,file)
        user.profile_image='img/save_user_file/profile/image/%s'%file_name
        user.save()
        return JsonResponse({1:1})
def send_img(request):
    if request.method == 'POST':
        if request.session['email']:
            user = Users.objects.get(email__contains = request.session['email'])
            data= {'profile_image':user.profile_image}
            return JsonResponse(data)
def read_site_info(request):
    all_site_info = Site_Info.objects.all()
    list_ = []
    for i in all_site_info:
        list_.append(model_to_dict(i))
    return JsonResponse(list_, safe=False)
def each_site_info(request):
    if request.method == 'POST':
        mode = request.POST.get('mode')
        if mode == 'check':
            site_id = request.POST.get('site_id')
            user = Users.objects.get(email = request.session['email'])
            site_owner = Site_Info.objects.get(id=site_id).user
            print(site_owner.email)
            site_info = Site_Info.objects.get(id=site_id)
            site_info = model_to_dict(site_info)
            site_info['status']='correct_user'
            if user == site_owner:
                print('해당유저')
                return JsonResponse(site_info)
            else:    
                print('다른유저')
                return JsonResponse({'status':'다른유저의 사이트 접근'})
def modify_each_site_info(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        site_name = data['site_name']
        site_url = data['site_url']
        site_id = data['target_site_id']
        site = Site_Info.objects.get(id = site_id)
        
        user = Users.objects.get(email= request.session['email'])
        site_list = user.site_info_set.all().values('site_name')
        site_list_ = []
        for i in site_list:
            site_list_.append(i['site_name'])
        print(site_list_)
        if site_name in site_list_:
            virtual_site_name = site_name+str(time())
        else:
            virtual_site_name = site_name
        print(virtual_site_name)
        site.site_url_link= site_url
        site.site_name = site_name
        site.virtual_site_name=virtual_site_name
        site.save()
        return JsonResponse({'status':'ok'})
def modify_article(request):
    if request.method == 'POST':
        article_id= request.POST['article_id']
        this_user = Users.objects.get(email = request.session['email'])
        request_article = Article_list.objects.get(id = article_id)
        article_owner = request_article.user
        if article_owner==this_user:
            article_dict = model_to_dict(request_article)
            return JsonResponse(article_dict)
        else:
            return HttpResponse('fail')
def delete_article(request):
    if request.method == 'POST':

        return JsonResponse()