from django.shortcuts import render
from django.http import JsonResponse, HttpResponse
from django.shortcuts import redirect, render
from django.forms.models import model_to_dict
import os
import pandas as pd
import json
from .models import *

class Article():
    def __init__(self) -> None:
        pass    
    def write(request):
        if request.method == 'POST':
            return HttpResponse(1)
        else:
            return HttpResponse(1)
    def update(request):
        if request.method == 'POST':
            return HttpResponse(1)
        else:
            return HttpResponse(1)
    def remove(request):
        if request.method == 'POST':
            return HttpResponse(1)
        else:
            return HttpResponse(1)
    def read(request):
        mode= request.GET.get('mode')
        if mode == 'date':
            return HttpResponse(1)
        if mode == 'tag':
            return HttpResponse(1)
        if mode == 'previous':
            return HttpResponse(1)
class Tag():
    def __init__(self) -> None:
        pass
    def read_base_tags(request):
        return HttpResponse('h1')
    def read_sub_tags(request):
        return HttpResponse('h1')
    def append_base_tags(request):
        if request.method == 'POST':
            return HttpResponse(1)
        else:
            return HttpResponse(1)
    def append_sub_tags(request):
        if request.method == 'POST':
            return HttpResponse(1)
        else:
            return HttpResponse(1)

def to_db(request):
    with open('json/tag.json', 'r', encoding='utf-8') as f:
        r = f.read()
        r  =json.loads(r)
        print(type(r), len(r['level']))
        for i in range(len(r['level'])):
            Tag_list(tag_name = r['name'][str(i)], tag_level=r['level'][str(i)]).save()
    return HttpResponse('ok')
# Create your views here.
import datetime
def addtag(request):
    try:
        if request.session['email']:
            return render(request, 'study/addtag.html')
    except:
        return redirect('/')
def signin(request):
    if request.method =='POST':
        email = request.POST.get('email')
        password = request.POST.get('user_pw')
        name=request.POST.get('name')
        nickname = request.POST.get('nickname')
        birthday=request.POST.get('birthday')
        gender=request.POST.get('gender')
        phone = request.POST.get('phone')
        signup_date = datetime.datetime.now().strftime('%Y%m%d') 
        Users(name=name,birthday=birthday,gender=gender,password=password,nickname=nickname,email=email, phone=phone, signup_date = signup_date).save()
        return redirect('/')
    try:
        if request.session['email']:
            return redirect('/')
    except:
        return render(request, 'study/signin.html')
def login(request):
    if request.method == 'POST':
        dict = json.loads(request.body)
        email = dict['email']
        user_pw = dict['user_pw']
        if Users.objects.filter(email=email, password=user_pw):
            request.session['email']=email
            request.session['nickname']=Users.objects.filter(email=email, password=user_pw)[0].nickname
            request.session['user_pw'] =user_pw
            status = '로그인정보일치'
            context={'status':status}
            return JsonResponse(context)
        else:
            status = '로그인오류'
            context={'status':status}
            return JsonResponse(context)
            
    else:
        return HttpResponse(1)
        
def check(request):
    try:
        if request.session['email']:
            return render(request, 'study/home.html')      
    except:
        return render(request, 'study/nosession.html')
def logout(request):
    request.session.flush()
    return redirect('/')



import re
####비동기 처리용
def verify_new_email(request):
    request_email = request.GET.get('email')
    request_email_domain = request.GET.get('email_domain')
    pattern = re.compile('[a-zA-Z]+\.{1}[a-zA-Z]+')
    pattern2 = re.compile('[a-zA-Z]+')
    if request_email=='undefined' or request_email=='none':
        return JsonResponse({'status':'이메일입력필수'})
    if pattern2.fullmatch(str(request_email))==None:
        return JsonResponse({'status':'이메일확인'})       
    if pattern.fullmatch(str(request_email_domain))==None:
        return JsonResponse({'status':'도메인확인'})       
    else:
        email = '@'.join([request_email, request_email_domain])
        if Users.objects.filter(email__contains=email):
            return JsonResponse({'status':'사용자중복'})
        else:
            return JsonResponse({'status':'사용가능'})