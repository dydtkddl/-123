function move_href(event){
    let loc = event.target.getAttribute('href')
    console.log(loc)
    location.href = loc
}
function change_id_input_border_focus(event){
    let target = event.target.getAttribute('linking')
    document.getElementsByName(target)[0].style.border = '2px solid rgb(5 70 189 / 73%)'
}
function change_id_input_border_blur(event){
    let target = event.target.getAttribute('linking')
    if ( target=='span01'){
    document.getElementsByName(target)[0].style.borderTop = '1px solid rgb(192, 192, 192)'
    document.getElementsByName(target)[0].style.borderLeft = '1px solid rgb(192, 192, 192)'
    document.getElementsByName(target)[0].style.borderRight = '1px solid rgb(192, 192, 192)'
    document.getElementsByName(target)[0].style.borderBottom = 'none'
    }else if(target=='span02'){
    document.getElementsByName(target)[0].style.border = '1px solid rgb(192, 192, 192)'
    }else if(target=='sign_span08'){
    document.getElementsByName(target)[0].style.border = '1px solid rgb(192, 192, 192)'
    }else {
        document.getElementsByName(target)[0].style.borderTop = '1px solid rgb(192, 192, 192)'
        document.getElementsByName(target)[0].style.borderLeft = '1px solid rgb(192, 192, 192)'
        document.getElementsByName(target)[0].style.borderRight = '1px solid rgb(192, 192, 192)'
        document.getElementsByName(target)[0].style.borderBottom = 'none' 
        }
    }
