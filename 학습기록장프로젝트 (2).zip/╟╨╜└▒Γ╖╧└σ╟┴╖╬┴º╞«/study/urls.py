from django.urls import path
from study import views
urlpatterns = [
    path('', views.check),
    path('check/', views.check),
    path('read_base_tags/', views.Tag.read_base_tags),
    path('read_sub_tags/', views.Tag.read_sub_tags),
    path('append_base_tags/', views.Tag.append_base_tags),
    path('append_sub_tags/', views.Tag.append_sub_tags),
    path('write_article/', views.Article.write),
    path('remove_article/', views.Article.remove),
    path('update_article/', views.Article.update),
    path('read_article/', views.Article.read),
    path('to_db/', views.to_db),
    path('addtag/', views.addtag),
    path('logout/', views.logout),
    path('login/', views.login),
    path('signin/', views.signin),
]
