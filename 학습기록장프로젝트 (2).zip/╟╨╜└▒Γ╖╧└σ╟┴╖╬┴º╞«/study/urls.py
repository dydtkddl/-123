from django.urls import path
from study import views
urlpatterns = [
    path('', views.check),
    path('check/', views.check),
    path('read_base_tags/', views.Tag.read_base_tags),
    path('read_sub_tags/', views.Tag.read_sub_tags),
    path('write_article/', views.Article.write),
    path('remove_article/', views.Article.remove),
    path('update_article/', views.Article.update),
    path('read_article/', views.Article.read),
    path('to_db/', views.to_db),
    path('logout/', views.logout),
    path('login/', views.login),
    path('signin/', views.signin),
    path('verify_new_email/', views.verify_new_email),
    path('remove_session/', views.remove_session),
    path('make_new_tag/', views.Tag.make_new_tag),
    path('read_all_tag/', views.Tag.read_all_tags),
    path('make_site_bookmark/', views.make_site_bookmark),
    path('read_site_info/', views.read_site_info),
]
