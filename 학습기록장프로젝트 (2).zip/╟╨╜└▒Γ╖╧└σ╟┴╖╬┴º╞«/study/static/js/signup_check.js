function show_password(event){
    let target= event.target;
    target.type = 'text';
    console.log(target)
}
function hide_password(event){
    let target= event.target;
    target.type = 'password';
    console.log(target)
}
function verify_password(event){
    let target = event.target;
    let o_pw = document.getElementById('password')
    console.log(1)
    if(target.value == o_pw.value){
        document.getElementById('password_checked').style.display='inline'
        document.getElementById('password_no_checked').style.display='none'
    }else{
        document.getElementById('password_checked').style.display='none'
        document.getElementById('password_no_checked').style.display='inline'
    }
}
