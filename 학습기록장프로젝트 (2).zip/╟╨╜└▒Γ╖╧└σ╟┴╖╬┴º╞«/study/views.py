from django.shortcuts import render
from django.http import JsonResponse, HttpResponse
from django.shortcuts import redirect, render
from django.forms.models import model_to_dict
import os
import pandas as pd
import json
from .models import *

class Article():
    def __init__(self) -> None:
        pass    
    def write(request):
        if request.method == 'POST':
            return HttpResponse(1)
        else:
            return HttpResponse(1)
    def update(request):
        if request.method == 'POST':
            return HttpResponse(1)
        else:
            return HttpResponse(1)
    def remove(request):
        if request.method == 'POST':
            return HttpResponse(1)
        else:
            return HttpResponse(1)
    def read(request):
        mode= request.GET.get('mode')
        if mode == 'date':
            return HttpResponse(1)
        if mode == 'tag':
            return HttpResponse(1)
        if mode == 'previous':
            return HttpResponse(1)
class Tag():
    def __init__(self) -> None:
        pass
    def read_base_tags(request):
        return HttpResponse('h1')
    def read_sub_tags(request):
        return HttpResponse('h1')
    def read_all_tags(request):
        try:
            if request.session['email']:
                level_zero_tags = Tag_list.objects.filter(tag_level__contains=0)
                level_one_tags = Tag_list.objects.filter(tag_level__contains=1)
                level_two_tags = Tag_list.objects.filter(tag_level__contains=2)
                context ={'level_zero_tags' : level_zero_tags,'level_one_tags' : level_one_tags,'level_two_tags' : level_two_tags } 
                return render(request, 'study/read_all_tag.html' ,context)
        except:
            return redirect('/')
    def make_new_tag(request):
        if request.method == 'POST':
            data = json.loads(request.body)
            print(data)
            if data['tag_name']=='':
                return JsonResponse({'status':'저장할 이름을 입력해야합니다.'})
            else:
                Tag_list(tag_name=data['tag_name'], tag_level=data['tag_depth']).save()
                return JsonResponse({'status':'저장완료'})
        else:
            HttpResponse('get접근')
def read_site_info(request):
    all_site_info = Site_Info.objects.all()
    list_ = []
    for i in all_site_info:
        list_.append(model_to_dict(i))
    return JsonResponse(list_, safe=False)
def make_site_bookmark(request):
    all_site_info = Site_Info.objects.all()
    list_ = []
    for i in all_site_info:
        list_.append(model_to_dict(i))
    return render(request, 'study/make_site_bookmark.html', {'site_list' :list_})
def to_db(request):
    # 자주가는 사이트 데이터베이스에 반영시키는
    if request.GET.get('mode'):
        mode = request.GET.get('mode')
        if mode == 'save_site':
            list_ = []
            dic = {}
            with open('study/static/홈피링크.txt', 'r', encoding='utf-8') as file:
                a = file.read()
                print(type(a))
                a = a.split('\n')
                
                for i in a[:-1]:
                    b = i.split('&')
                    dic[b[0]]=b[1]
                    img_link = 'img/사이트아이콘/%s.png'
                    img_link = img_link%b[0]
                    Site_Info(site_name=b[0], site_url_link=b[1] , site_img_link=img_link).save()                    
            return HttpResponse(dic.items())
    # 기본태그 넣어주는
    with open('json/tag.json', 'r', encoding='utf-8') as f:
        r = f.read()
        r  =json.loads(r)
        print(type(r), len(r['level']))
        for i in range(len(r['level'])):
            Tag_list(tag_name = r['name'][str(i)], tag_level=r['level'][str(i)]).save()
    return HttpResponse('ok')
# Create your views here.
import datetime
def signin(request):
    if request.method =='POST':
        email = request.POST.get('email')
        email_domain =request.POST.get('email_domain')
        db_email = '@'.join([email, email_domain])
        password = request.POST.get('user_pw')
        password_re = request.POST.get('check_pw')
        name=request.POST.get('name')
        nickname = request.POST.get('nickname')
        birthday_year=request.POST.get('birthday_year')
        birthday_month=request.POST.get('birthday_month')
        birthday_date=request.POST.get('birthday_date')
        birthday = '/'.join([birthday_year, birthday_month, birthday_date])
        gender=request.POST.get('gender')
        phone = request.POST.get('phone')
        signup_date = datetime.datetime.now().strftime('%Y%m%d') 

        pattern = re.compile('[a-zA-Z]+\.{1}[a-zA-Z]+')
        pattern2 = re.compile('[a-zA-Z]+')
        if Users.objects.filter(email__contains = db_email):
            return render(request,'study/signin.html', {'status_code':'중복되는 이메일이 존재합니다'})
        elif email=='undefined' or email=='none':
            return render(request,'study/signin.html', {'status_code':'이메일 필수'})
        elif pattern2.fullmatch(str(email))==None:
            return render(request,'study/signin.html', {'status_code':'이메일 형식이 올바르지 않습니다.'}) 
        elif pattern.fullmatch(str(email_domain))==None:
            return render(request,'study/signin.html', {'status_code':'도메인 형식이 올바르지 않습니다'})  
        
        elif password!=None and name !=None and nickname !=None and birthday_year != None and birthday_month != None and birthday_date != None and gender != None and phone !=None:
            if password != password_re:
                print(password, password_re)
                return render(request,'study/signin.html', {'status_code':'비밀번호 확인을 비밀번호와 동일하게 작성해주세요'})  
            else:
                Users(name=name,birthday=birthday,gender=gender,password=password,nickname=nickname,email=db_email, phone=phone, signup_date = signup_date).save()
                return redirect('/')
        else:
            return render(request,'study/signin.html', {'status_code':'모든 정보를 입력해주세요'})  
    try:
        if request.session['email']:
            return redirect('/')
    except:
        return render(request, 'study/signin.html', {'status_code':'최초접근'})
def login(request):
    if request.method == 'POST':
        dict = json.loads(request.body)
        email = dict['email']
        user_pw = dict['user_pw']
        if Users.objects.filter(email=email, password=user_pw):
            request.session['email']=email
            request.session['nickname']=Users.objects.filter(email=email, password=user_pw)[0].nickname
            request.session['user_pw'] =user_pw
            status = '로그인정보일치'
            context={'status':status}
            return JsonResponse(context)
        else:
            status = '로그인오류'
            context={'status':status}
            return JsonResponse(context)
            
    else:
        return HttpResponse(1)
        
def check(request):
    try:
        if request.session['email']:
            return render(request, 'study/home.html')      
    except:
        return render(request, 'study/nosession.html')
def logout(request):
    request.session.flush()
    return redirect('/')
def remove_session(request):
    request.session.flush()
    return HttpResponse('/')



import re
####비동기 처리용
def verify_new_email(request):
    request_email = request.GET.get('email')
    request_email_domain = request.GET.get('email_domain')
    pattern = re.compile('[a-zA-Z]+\.{1}[a-zA-Z]+')
    pattern2 = re.compile('[a-zA-Z]+')
    if request_email=='undefined' or request_email=='none':
        return JsonResponse({'status':'이메일입력필수'})
    if pattern2.fullmatch(str(request_email))==None:
        return JsonResponse({'status':'이메일 형식이 올바르지 않습니다.'})       
    if pattern.fullmatch(str(request_email_domain))==None:
        return JsonResponse({'status':'도메인 형식이 올바르지 않습니다'})       
    else:
        email = '@'.join([request_email, request_email_domain])
        print(email)
        if Users.objects.filter(email__contains=email):
            return JsonResponse({'status':'이미 존재하는 사용자'})
        else:
            return JsonResponse({'status':'사용가능'})
