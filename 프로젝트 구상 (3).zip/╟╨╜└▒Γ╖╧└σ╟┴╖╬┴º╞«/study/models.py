from django.db import models

class Site_Info(models.Model):
    site_name = models.CharField(max_length=100)
    site_url_link = models.CharField(max_length=120)
    site_img_link = models.CharField(max_length=120)
class Users(models.Model):
    email = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
    name = models.CharField(max_length=100)
    nickname = models.CharField(max_length=100)
    birthday = models.CharField(max_length=100)
    gender = models.CharField(max_length=100)
    phone = models.CharField(max_length=100)
    signup_date = models.CharField(max_length=100)
    profile_image = models.CharField(max_length=100, null = True , default='img/save_user_file/profile/image/default_img.jpg')
    own_site = models.ManyToManyField(Site_Info)
class Article_list(models.Model):
    writer = models.CharField(max_length=100)
    title = models.CharField(max_length=100)
    content = models.TextField()
    original_article_id = models.IntegerField()
    date = models.CharField(max_length=100)
class Tag_list(models.Model):
    tag_name = models.CharField(max_length=100)
    tag_level = models.IntegerField()
    articles = models.ManyToManyField(Article_list)
class Deep_Tag(models.Model):
    tag_name = models.CharField(max_length=100)
    tag_level = models.IntegerField(default=2)
    upper_tag = models.ForeignKey(Tag_list, on_delete=models.CASCADE)
class Memo(models.Model):
    content = models.TextField()
    date = models.CharField(max_length=100)

# Create your models here.
